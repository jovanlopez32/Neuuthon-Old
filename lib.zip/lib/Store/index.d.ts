import makeInMemoryStore from './make-in-memory-store';
export { makeInMemoryStore };
